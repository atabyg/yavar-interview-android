import type { InterviewKind } from "./types.ts";

/** Control-list questions. PDF page numbers are unknown until the official files are loaded. */
export const RULES_META = {
  version: "control-list-v1.0",
  issued: "1405",
  pdfVerified: false,
  source:
    "فهرست کنترل بند ۷ ابرپرامپت. متن کامل شیوه‌نامه و پشتوانه علمی در این ساخت پیوست نبود؛ در اختلاف، PDF ملاک است و اینجا تغییری در قاعده داده نشده.",
} as const;

export interface QuestionDef {
  id: string;
  critical: boolean;
  /** Provisional urgent subset only. The official six are not in the attached control list. */
  urgentProvisional: boolean;
  text: string;
}

export const QUESTIONS: QuestionDef[] = [
  { id: "H01", critical: true, urgentProvisional: true, text: "اگر خروج شما فردا قطعی شود، سه کار اول شما چیست؟ زمان و مکان هرکدام را بگویید." },
  { id: "H02", critical: true, urgentProvisional: true, text: "۷۲ ساعت اول بعد از خروج را قدم‌به‌قدم توضیح دهید." },
  { id: "H03", critical: true, urgentProvisional: true, text: "اگر کسی از ارتباطات قبلی شما دعوتی بدهد که مسیر جدیدتان را به خطر بیندازد، چه می‌کنید؟" },
  { id: "H04", critical: true, urgentProvisional: true, text: "اگر همکاری رفتار یا پیشنهادی برخلاف برنامه شما مطرح کند، یک پاسخ واقعی و کوتاه بگویید." },
  { id: "H05", critical: true, urgentProvisional: true, text: "چه چیزی ممکن است باعث شود کار را رها کنید و چه برنامه‌ای برای آن دارید؟" },
  { id: "H06", critical: true, urgentProvisional: true, text: "چه کسی از برنامه کار شما خبر دارد و دقیقاً چه کمکی می‌تواند بکند؟" },
  { id: "H07", critical: true, urgentProvisional: false, text: "آخرین بار که تحت فشار یا عصبانیت شدید بودید، چه شد و دقیقاً چه کردید؟" },
  { id: "H08", critical: true, urgentProvisional: false, text: "اگر شروع کار یک هفته عقب بیفتد، اما مسیر مطمئن‌تری پیدا شود، چه می‌کنید؟" },
  { id: "H09", critical: true, urgentProvisional: false, text: "اگر مانع غیرمنتظره‌ای در روز اول ایجاد شود، چه تصمیم عملی می‌گیرید؟" },
  { id: "H10", critical: true, urgentProvisional: false, text: "چرا می‌خواهید وارد این کار شوید و اگر کار دلخواه آماده نباشد، چه گزینه‌ای را می‌پذیرید؟" },
  { id: "H11", critical: true, urgentProvisional: false, text: "اگر اولین شغل مطابق انتظار شما نبود، سه راه جایگزین شما چیست؟" },
  { id: "H12", critical: true, urgentProvisional: false, text: "اگر در محل کار اشتباه کنید، اولین اقدام شما و اولین فردی که مطلع می‌کنید چیست؟" },
  { id: "Q13", critical: false, urgentProvisional: false, text: "چه چیزی در زندگی شما با داشتن این شغل واقعاً تغییر می‌کند؟ یک مثال عملی بزنید." },
  { id: "Q14", critical: false, urgentProvisional: false, text: "عنوان شغل، محل، ساعت و وظیفه اصلی کار موردنظر شما چیست و این اطلاعات را از کجا دارید؟" },
  { id: "Q15", critical: false, urgentProvisional: false, text: "از حقوق و شرایط کار چه انتظاری دارید و برای این انتظار چه سابقه یا مهارتی دارید؟" },
  { id: "Q16", critical: false, urgentProvisional: false, text: "یک روز کاری قبلی خود را از شروع تا پایان، مرحله‌به‌مرحله تعریف کنید." },
  { id: "Q17", critical: false, urgentProvisional: false, text: "اگر کاری را بلد نباشید، دقیقاً برای یادگیری چه می‌کنید و از چه کسی کمک می‌گیرید؟" },
  { id: "Q18", critical: false, urgentProvisional: false, text: "مسیر رفت‌وآمد شما چیست؟ وسیله، زمان تقریبی و هزینه را بگویید." },
  { id: "Q19", critical: false, urgentProvisional: false, text: "بعد از پذیرش در مرکز مقصد، چگونه و به چه کسی پاسخگو خواهید بود؟" },
  { id: "Q20", critical: false, urgentProvisional: false, text: "اگر پاسخ یک سؤال را ندانید یا مطمئن نباشید، چه می‌گویید و چه می‌کنید؟" },
  { id: "Q21", critical: false, urgentProvisional: false, text: "کدام بخش کاری را برای خودتان سخت‌تر از آنچه ابتدا فکر می‌کردید می‌دانید؟" },
  { id: "Q22", critical: false, urgentProvisional: false, text: "بخشی از توضیح قبلی‌تان را دوباره و این بار با ترتیب زمانی، مکان و افراد بازگو کنید." },
  { id: "Q23", critical: false, urgentProvisional: false, text: "برای هفته اول، دقیقاً چه کسی، چه زمانی و چگونه می‌تواند به شما کمک کند؟" },
  { id: "Q24", critical: false, urgentProvisional: false, text: "اگر کارشناس بگوید بخشی از برنامه شما هنوز روشن نیست، چه اطلاعات یا مدرکی برای روشن‌شدن آن ارائه می‌کنید؟" },
];

export const CRITICAL_IDS = QUESTIONS.filter((q) => q.critical).map((q) => q.id);
export const URGENT_IDS = QUESTIONS.filter((q) => q.urgentProvisional).map((q) => q.id);
export const FULL_IDS = QUESTIONS.map((q) => q.id);

export function scopeIds(kind: InterviewKind): string[] {
  return kind === "urgent" ? URGENT_IDS : FULL_IDS;
}

export function questionById(id: string): QuestionDef | undefined {
  return QUESTIONS.find((q) => q.id === id);
}
