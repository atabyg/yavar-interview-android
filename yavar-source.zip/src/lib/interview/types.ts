export type InterviewKind = "full" | "urgent";

export type CaseStatus = "draft" | "recording" | "review" | "signed";

export type Speaker = "client" | "interviewer" | "overlap";

export type AnswerStatus =
  | "answered"
  | "partial"
  | "unanswered"
  | "contradictory"
  | "unclear"
  | "needs_review";

export type EvidenceOrigin = "none" | "manual_hearing" | "segment";

export interface Segment {
  id: string;
  speaker: Speaker;
  textRaw: string;
  startSec: number | null;
  endSec: number | null;
  /** Engine value only. Null when the engine did not provide one. */
  confidence: number | null;
  origin: "manual" | "browser_speech";
}

export interface Answer {
  evidenceText: string;
  evidenceOrigin: EvidenceOrigin;
  segmentIds: string[];
  speakerConfirmedClient: boolean;
  status: AnswerStatus;
  expertScore: 0 | 1 | 2 | null;
  zeroResolved: boolean;
  note: string;
}

export interface Deduction {
  requested: number;
  evidence: string;
  contextTime: string;
  repetition: string;
  baseline: string;
  confoundersChecked: boolean;
}

export interface AuditEvent {
  at: string;
  action: string;
  detail: string;
}

export interface CaseFile {
  id: string;
  synthetic: boolean;
  code: string;
  alias: string;
  center: string;
  expertName: string;
  secondExpertName: string;
  consentRecorded: boolean;
  consentExplained: boolean;
  consentRefused: boolean;
  dischargeConfirmed: boolean;
  psychCrisis: boolean;
  medicalUnstable: boolean;
  noSafeNight: boolean;
  clinicalGateActive: boolean;
  clinicalCleared: boolean;
  kind: InterviewKind;
  urgentReason: string;
  status: CaseStatus;
  createdAt: string;
  updatedAt: string;
  segments: Segment[];
  answers: Record<string, Answer>;
  deduction: Deduction;
  audioStored: boolean;
  recordingSeconds: number;
  expertApprovedAt: string | null;
  secondApprovedAt: string | null;
  cloudAsrConsent: boolean;
  audit: AuditEvent[];
}

export interface Settings {
  orgTitle: string;
  deptTitle: string;
  centerDefault: string;
  autoLockMin: number;
  /** Never copied into reports or exports. */
  endPhrase: string;
  allowBrowserSpeech: boolean;
}

export interface PinRecord {
  saltB64: string;
  hashB64: string;
  iterations: number;
}

export type View =
  | "lock"
  | "home"
  | "case"
  | "ready"
  | "record"
  | "transcript"
  | "questions"
  | "summary"
  | "report"
  | "settings"
  | "method";
